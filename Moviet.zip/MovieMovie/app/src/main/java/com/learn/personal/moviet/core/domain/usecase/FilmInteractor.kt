package com.learn.personal.moviet.core.domain.usecase

class FilmInteractor {
}
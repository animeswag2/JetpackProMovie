package com.learn.personal.moviet.ui.favourite

class FavouriteFragmentCallback {
}
package com.learn.personal.moviet.data.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}
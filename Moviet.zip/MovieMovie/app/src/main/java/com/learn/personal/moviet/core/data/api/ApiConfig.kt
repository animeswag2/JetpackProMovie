package com.learn.personal.moviet.core.data.api

class ApiConfig {
    companion object {
        const val BASE_URL = "https://api.themoviedb.org/3/"
        const val TMDB_API_KEY = "8ba9eb456cc03b328b64daa303e1e364"
        const val IMG_URL = "https://image.tmdb.org/t/p/w500"
    }
}
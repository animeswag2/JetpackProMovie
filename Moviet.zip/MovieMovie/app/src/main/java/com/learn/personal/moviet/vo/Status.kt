package com.learn.personal.moviet.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}
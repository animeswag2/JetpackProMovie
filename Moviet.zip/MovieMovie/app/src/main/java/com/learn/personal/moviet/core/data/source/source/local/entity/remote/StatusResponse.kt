package com.learn.personal.moviet.core.data.source.source.local.entity.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}